"""
Extracção e validação de ``content_blocks`` JSON opcional no texto do assistente.

O modelo pode terminar a mensagem com um fenced block `` ```json ... ``` `` contendo
``{"version": 1, "content_blocks": [...]}`` para o SmartChat renderizar tabelas / métricas.
A chave legada ``blocks`` ainda é aceite no parse e normalizada para ``content_blocks``.
"""

from __future__ import annotations

import json
import re
from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

__all__ = [
    "ContentBlocksPayload",
    "split_reply_and_blocks",
]


class BlockParagraph(BaseModel):
    model_config = ConfigDict(extra="ignore")

    type: Literal["paragraph"] = "paragraph"
    text: str


class BlockHeading(BaseModel):
    model_config = ConfigDict(extra="ignore")

    type: Literal["heading"] = "heading"
    level: Literal[1, 2, 3] = 2
    text: str


class BlockTable(BaseModel):
    model_config = ConfigDict(extra="ignore")

    type: Literal["table"] = "table"
    columns: list[str]
    rows: list[list[Any]]


class BlockMetricItem(BaseModel):
    model_config = ConfigDict(extra="ignore")

    label: str
    value: str


class BlockMetricGrid(BaseModel):
    model_config = ConfigDict(extra="ignore")

    type: Literal["metric_grid"] = "metric_grid"
    items: list[BlockMetricItem]


ContentBlock = Annotated[
    Union[BlockParagraph, BlockHeading, BlockTable, BlockMetricGrid],
    Field(discriminator="type"),
]


class ContentBlocksPayload(BaseModel):
    model_config = ConfigDict(extra="ignore")

    version: Literal[1] = 1
    content_blocks: list[ContentBlock]

    @model_validator(mode="before")
    @classmethod
    def _coerce_legacy_blocks_key(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        out = dict(data)
        if "content_blocks" not in out and "blocks" in out:
            out["content_blocks"] = out["blocks"]
        return out


_FENCE_RE = re.compile(r"```(?:json)?\s*([\s\S]*?)```", re.IGNORECASE)


def split_reply_and_blocks(assistant_content: str) -> tuple[str, dict[str, Any] | None]:
    """
    Remove o último fenced JSON válido (``ContentBlocksPayload``) do texto e devolve
    ``(texto_para_o_utilizador, payload_serializado_ou_None)``.
    """
    if not assistant_content or not assistant_content.strip():
        return assistant_content, None
    text = assistant_content
    matches = list(_FENCE_RE.finditer(text))
    for m in reversed(matches):
        raw = m.group(1).strip()
        if not raw.startswith("{"):
            continue
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict):
            continue
        if "content_blocks" not in data and "blocks" not in data:
            continue
        try:
            payload = ContentBlocksPayload.model_validate(data)
        except ValidationError:
            continue
        before = text[: m.start()].rstrip()
        after = text[m.end() :].lstrip()
        display = f"{before}\n\n{after}".strip() if after else before
        return display, payload.model_dump(mode="json")
    stripped = text.strip()
    if stripped.startswith("{") and (
        '"content_blocks"' in stripped or '"blocks"' in stripped
    ):
        try:
            data = json.loads(stripped)
            payload = ContentBlocksPayload.model_validate(data)
            return "", payload.model_dump(mode="json")
        except (json.JSONDecodeError, ValidationError):
            pass
    return assistant_content, None
